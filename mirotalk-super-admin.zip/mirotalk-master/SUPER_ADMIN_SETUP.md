# SUPER ADMIN login (custom MiroTalk P2P change)

This fork adds a site-wide SUPER ADMIN sign-in option to the pre-join name/device dialog.
It is separate from MiroTalk's existing `HOST_USERS` and room Host permissions.

## Configure on Render

1. Open your Render service.
2. Open **Environment**.
3. Add `SUPER_ADMIN_PASSWORD` with a long, unique password (at least 12 characters).
4. Keep the existing `JWT_KEY` configured with a strong random value (at least 32 characters, as required by MiroTalk).
5. Save changes and redeploy.

Do not put the real password in `.env.template`, JavaScript, HTML, or GitHub.

## Sign in

1. Open a room and wait for the pre-join dialog.
2. Tick **管理者としてログインする**.
3. Enter the `SUPER_ADMIN_PASSWORD` value.
4. Join the meeting. The server verifies a signed token and grants presenter/Host controls in every room.

The admin token expires after 12 hours and is stored in the current browser tab's session storage. Unticking the checkbox on a subsequent join removes the browser's stored admin token.

## Security notes

- The password is checked only by the server over HTTPS.
- The browser never receives the configured password.
- A checkbox alone cannot grant admin privileges; each room join is verified server-side.
- Failed login attempts use the existing login rate limiter.
- This change grants room-level presenter controls across rooms. It does not yet add a separate dashboard for listing/managing all rooms or server-wide user accounts.
- This project remains under the upstream AGPL-3.0 license; preserve the license and provide corresponding source when distributing a modified network service as required by the license.
