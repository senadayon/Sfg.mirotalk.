'use strict';

/**
 * Dev helper: generate the in-room UI translation template (public/lang/en.json).
 *
 * Scans the source of every page that loads i18n.js (in-room, login, waiting room) for
 * user-facing English strings and groups them by
 * namespace (tooltips / buttons / labels / dialogs / toasts). Values are the English
 * source itself so translators can copy en.json -> <lang>.json and fill in.
 *
 * Usage: node scripts/extract-ui-lang.js
 *
 * The output is a starting point and should be reviewed by hand before shipping.
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const VIEWS_DIR = path.join(ROOT, 'public/views');
const LANG_DIR = path.join(ROOT, 'public/lang');
const OUT_FILE = path.join(LANG_DIR, 'en.json');

const ATTR_KEYS = ['title', 'placeholder', 'aria-label', 'data-tippy-content'];
const DIALOG_FIELDS = [
    'title',
    'titleText',
    'text',
    'confirmButtonText',
    'cancelButtonText',
    'denyButtonText',
    'inputLabel',
    'inputPlaceholder',
    'footer',
];

const buckets = {
    tooltips: new Set(),
    buttons: new Set(),
    labels: new Set(),
    dialogs: new Set(),
    toasts: new Set(),
};

function decodeEntities(str) {
    return str
        .replace(/&nbsp;/g, ' ')
        .replace(/&amp;/g, '&')
        .replace(/&copy;/g, '\u00a9')
        .replace(/&times;/g, '\u00d7')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>');
}

function normalize(str) {
    return decodeEntities(str).replace(/\s+/g, ' ').trim();
}

const STOPLIST = new Set([
    'in',
    'or',
    'on',
    'off',
    'none',
    'fill',
    'true',
    'false',
    'the',
    'polls',
    'recording',
    'screen',
    'settings',
    'microphone',
    'whiteboard',
    'the file',
    'nameTitle',
    'UserName',
    'scale-down',
]);

function isTranslatable(str) {
    if (!str || str.length < 2) return false;
    if (str.includes('{{') || str.includes('${') || str.includes('<')) return false;
    if (!/[a-zA-Z]/.test(str)) return false; // must contain letters
    if (/:\/\//.test(str)) return false; // any URL/scheme
    if (/^[A-Za-z]$/.test(str)) return false; // single letter (shortcut keys)
    if (/x{4,}/.test(str)) return false; // placeholder patterns
    if (/^(?:©\s*\d{4}\s+)?MiroTalk\b/.test(str)) return false; // brand-managed titles / copyright
    if (STOPLIST.has(str)) return false;
    if (str.length > 220) return false;
    return true;
}

function add(bucket, raw) {
    const value = normalize(raw);
    if (isTranslatable(value)) buckets[bucket].add(value);
}

function unescapeJs(str) {
    return str.replace(/\\(['"\\])/g, '$1').replace(/\\n/g, ' ');
}

// Pages that load i18n.js (in-room, login, waiting room) share the same dictionary.
function getI18nPages() {
    const i18nScriptRe = /<script[^>]+src\s*=\s*['"]\.\.\/js\/i18n\.js['"]/i;
    return fs
        .readdirSync(VIEWS_DIR)
        .filter((file) => file.endsWith('.html'))
        .sort()
        .map((file) => path.join(VIEWS_DIR, file))
        .filter((file) => i18nScriptRe.test(fs.readFileSync(file, 'utf8')));
}

// Local scripts loaded by every i18n page (runtime strings share the same dictionary).
function getI18nJsFiles() {
    const files = new Set();
    const scriptRe = /<script[^>]+src\s*=\s*['"]\.\.\/js\/([^'"?#]+\.js)['"]/gi;
    for (const page of getI18nPages()) {
        const html = fs.readFileSync(page, 'utf8');
        let match;
        while ((match = scriptRe.exec(html))) files.add(path.join(ROOT, 'public/js', match[1]));
    }
    return [...files];
}

function seedCuratedKeys() {
    if (!fs.existsSync(OUT_FILE)) return;
    const english = JSON.parse(fs.readFileSync(OUT_FILE, 'utf8'));
    for (const [namespace, entries] of Object.entries(english)) {
        if (!buckets[namespace] || !entries || typeof entries !== 'object') continue;
        for (const key of Object.keys(entries)) add(namespace, key);
    }
}

function scanCallbackReturns(src, property, bucket) {
    const callbackRe = new RegExp(`\\b${property}\\s*:\\s*\\([^)]*\\)\\s*=>\\s*\\{`, 'g');
    let callback;
    while ((callback = callbackRe.exec(src))) {
        const start = callbackRe.lastIndex;
        let depth = 1;
        let index = start;
        let quote = null;
        let escaped = false;

        for (; index < src.length && depth > 0; index++) {
            const char = src[index];
            if (quote) {
                if (escaped) escaped = false;
                else if (char === '\\') escaped = true;
                else if (char === quote) quote = null;
                continue;
            }
            if (char === "'" || char === '"' || char === '`') quote = char;
            else if (char === '{') depth++;
            else if (char === '}') depth--;
        }

        const body = src.slice(start, index - 1);
        const returnRe = /return\s+(?:[^;?\n]+\?\s*)?(['"])((?:\\.|(?!\1).)*)\1(?:\s*:\s*(['"])((?:\\.|(?!\3).)*)\3)?/g;
        let returned;
        while ((returned = returnRe.exec(body))) {
            add(bucket, unescapeJs(returned[2]));
            if (returned[4]) add(bucket, unescapeJs(returned[4]));
        }
    }
}

// ####################################################
// JS scan
// ####################################################

function scanJs(file) {
    const src = fs.readFileSync(file, 'utf8');
    let m;

    // Tooltips: setTippy(<id>, '<text>', ...)
    const tippyRe = /setTippy\(\s*[^,]+?,\s*(['"])((?:\\.|(?!\1).)*)\1/g;
    while ((m = tippyRe.exec(src))) add('tooltips', unescapeJs(m[2]));

    // Tooltips written as ternaries: setTippy(<id>, cond ? '<a>' : '<b>', ...)
    const tippyTernRe = /setTippy\([^,]+,\s*[^,?'"]*\?\s*(['"])((?:\\.|(?!\1).)*)\1\s*:\s*(['"])((?:\\.|(?!\3).)*)\3/g;
    while ((m = tippyTernRe.exec(src))) {
        add('tooltips', unescapeJs(m[2]));
        add('tooltips', unescapeJs(m[4]));
    }

    // Toasts: userLog(<type>, '<text>', ...) / toastMessage(<icon>, '<title>', ...) / msgPopup(<icon>, '<text>', ...)
    const logRe = /(?:userLog|toastMessage|msgPopup)\(\s*[^,]+?,\s*(['"])((?:\\.|(?!\1).)*)\1/g;
    while ((m = logRe.exec(src))) add('toasts', unescapeJs(m[2]));

    const logTernRe =
        /(?:userLog|toastMessage|msgPopup)\(\s*[^,]+?,\s*[^,?'"`]*\?\s*(['"])((?:\\.|(?!\1).)*)\1\s*:\s*(['"])((?:\\.|(?!\3).)*)\3/g;
    while ((m = logTernRe.exec(src))) {
        add('toasts', unescapeJs(m[2]));
        add('toasts', unescapeJs(m[4]));
    }

    // Dialogs: Swal.fire fields (string literals)
    const fieldRe = new RegExp(`\\b(${DIALOG_FIELDS.join('|')})\\s*:\\s*(['"])((?:\\\\.|(?!\\2).)*)\\2`, 'g');
    while ((m = fieldRe.exec(src))) add('dialogs', unescapeJs(m[3]));

    // Dialogs: Swal.fire fields using backtick literals without interpolation
    const fieldTplRe = new RegExp(`\\b(${DIALOG_FIELDS.join('|')})\\s*:\\s*\`([^\`$]*)\``, 'g');
    while ((m = fieldTplRe.exec(src))) add('dialogs', unescapeJs(m[2]));

    const conditionalFieldRe = new RegExp(
        `\\b(${DIALOG_FIELDS.join('|')})\\s*:\\s*[^,?]+\\?\\s*(['"])((?:\\\\.|(?!\\2).)*)\\2\\s*:\\s*(['"])((?:\\\\.|(?!\\4).)*)\\4`,
        'g'
    );
    while ((m = conditionalFieldRe.exec(src))) {
        add('dialogs', unescapeJs(m[3]));
        add('dialogs', unescapeJs(m[5]));
    }

    // Dialog strings passed through the runtime translation helper.
    const dialogTextRe = /translateDialogText\(\s*(['"])((?:\\.|(?!\1).)*)\1\s*\)/g;
    while ((m = dialogTextRe.exec(src))) add('dialogs', unescapeJs(m[2]));

    const validationRe = /Swal\.showValidationMessage\(\s*(?:t\(\s*)?(['"])((?:\\.|(?!\1).)*)\1/g;
    while ((m = validationRe.exec(src))) add('dialogs', unescapeJs(m[2]));

    scanCallbackReturns(src, 'inputValidator', 'dialogs');

    // Explicit translation calls mark dynamically-built labels that a DOM scan cannot infer.
    const translateRe = /\bt\(\s*(['"])((?:\\.|(?!\1).)*)\1\s*\)/g;
    while ((m = translateRe.exec(src))) add('labels', unescapeJs(m[2]));

    // Namespace-aware runtime translations for dynamic controls.
    const namespacedTranslateRe =
        /(?:window\.)?i18n\?*\.t\(\s*(['"])((?:\\.|(?!\1).)*)\1\s*,\s*(['"])(tooltips|buttons|labels|dialogs|toasts)\3\s*\)/g;
    while ((m = namespacedTranslateRe.exec(src))) add(m[4], unescapeJs(m[2]));

    // Dynamic attributes translated through the local setTranslatedAttribute helper.
    const translatedAttributeRe =
        /setTranslatedAttribute\(\s*[^,]+,\s*(['"])[^'"]+\1,\s*(?:[^,?()]+\?\s*)?(['"])((?:\\.|(?!\2).)*)\2(?:\s*:\s*(['"])((?:\\.|(?!\4).)*)\4)?,\s*(['"])(tooltips|buttons|labels|dialogs|toasts)\6\s*\)/g;
    while ((m = translatedAttributeRe.exec(src))) {
        add(m[7], unescapeJs(m[3]));
        if (m[5]) add(m[7], unescapeJs(m[5]));
    }

    // Login / waiting room texts translated at runtime through local helpers (labels namespace).
    const pageTextRe =
        /\b(?:showLoginError|translateLoginText|translateWaitingText)\(\s*(?:[^,?()'"]+\?\s*)?(['"])((?:\\.|(?!\1).)*)\1(?:\s*:\s*(['"])((?:\\.|(?!\3).)*)\3)?/g;
    while ((m = pageTextRe.exec(src))) {
        add('labels', unescapeJs(m[2]));
        if (m[4]) add('labels', unescapeJs(m[4]));
    }
    // Waiting room BRAND texts: the English fallback is translated at runtime.
    const waitingRoomTextRe = /\bgetWaitingRoomBrand\(\s*[^,]+,\s*(['"])((?:\\.|(?!\1).)*)\1/g;
    while ((m = waitingRoomTextRe.exec(src))) add('labels', unescapeJs(m[2]));

    // Declarative tooltip keys used by dynamically-built controls.
    const tooltipListRe = /\bconst\s+\w*TooltipLabels\s*=\s*\[([\s\S]*?)\];/g;
    let tooltipList;
    while ((tooltipList = tooltipListRe.exec(src))) {
        const stringRe = /(['"])((?:\\.|(?!\1).)*)\1/g;
        while ((m = stringRe.exec(tooltipList[1]))) add('tooltips', unescapeJs(m[2]));
    }

    // Dynamically-built UI text: text nodes and textContent/innerText assignments.
    const textNodeRe = /createTextNode\(\s*(['"])((?:\\.|(?!\1).)*)\1/g;
    while ((m = textNodeRe.exec(src))) add('labels', unescapeJs(m[2]));
    const textContentRe = /\.(?:textContent|innerText)\s*=\s*(['"])((?:\\.|(?!\1).)*)\1/g;
    while ((m = textContentRe.exec(src))) add('labels', unescapeJs(m[2]));

    // Device menu headers/options: appendMenuHeader(el, icon, '<text>') / appendSelectOptions(el, sel, '<text>', ...)
    const helperRe = /(?:appendMenuHeader|appendSelectOptions)\([^,]*,[^,]*,\s*(['"])((?:\\.|(?!\1).)*)\1/g;
    while ((m = helperRe.exec(src))) add('labels', unescapeJs(m[2]));

    // Participant dropdown menu items: getMsgerParticipantDropdownActionMarkup(id, icon, '<label>', ...)
    const dropdownRe = /getMsgerParticipantDropdownActionMarkup\([^,]*,[^,]*,\s*(['"])((?:\\.|(?!\1).)*)\1/g;
    while ((m = dropdownRe.exec(src))) add('buttons', unescapeJs(m[2]));

    // Video-tile menu items: createDropdownItem / createResponsiveDropdownItem(btn, '<label>', ...)
    const dropdownItemRe = /(?:createDropdownItem|createResponsiveDropdownItem)\([^,]+,\s*(['"])((?:\\.|(?!\1).)*)\1/g;
    while ((m = dropdownItemRe.exec(src))) add('buttons', unescapeJs(m[2]));

    // Dynamic UI labels passed as object props or default params (participant subtitles, file picker copy).
    const subtitleRe =
        /(?:participantSubtitle|emptyStateTitle|emptyStateSubtitle|helperText)\s*[:=]\s*(['"])((?:\\.|(?!\1).)*)\1/g;
    while ((m = subtitleRe.exec(src))) add('labels', unescapeJs(m[2]));

    // helperText assigned via a short ternary: capture the plain-string branch.
    const helperTernRe = /helperText:[^,{}]{0,160}?\?\s*(['"])((?:\\.|(?!\1).)*)\1/g;
    while ((m = helperTernRe.exec(src))) add('labels', unescapeJs(m[2]));
}

// ####################################################
// HTML scan (button-aware state machine)
// ####################################################

function scanHtml(file) {
    let html = fs.readFileSync(file, 'utf8');
    // Drop comments and script/style blocks entirely.
    html = html
        .replace(/<!--[\s\S]*?-->/g, '')
        .replace(/<script[\s\S]*?<\/script>/gi, '')
        .replace(/<style[\s\S]*?<\/style>/gi, '');

    const tagRe = /<(\/?)([a-zA-Z0-9-]+)((?:[^>"']|"[^"]*"|'[^']*')*)>/g;
    let lastIndex = 0;
    let buttonDepth = 0;
    let match;

    const handleText = (text) => {
        const bucket = buttonDepth > 0 ? 'buttons' : 'labels';
        // A run of text may contain multiple entities/newlines; treat as one label.
        add(bucket, text);
    };

    const handleAttrs = (tagName, attrStr) => {
        const isButton = tagName === 'button';
        const bucket = isButton || buttonDepth > 0 ? 'buttons' : 'labels';
        for (const key of ATTR_KEYS) {
            const re = new RegExp(`(?:^|\\s)${key}\\s*=\\s*(['"])(.*?)\\1`, 'i');
            const am = re.exec(attrStr);
            if (am) add(bucket, am[2]);
        }
    };

    while ((match = tagRe.exec(html))) {
        const text = html.slice(lastIndex, match.index);
        if (text.trim()) handleText(text);
        lastIndex = tagRe.lastIndex;

        const closing = match[1] === '/';
        const tagName = match[2].toLowerCase();
        const attrStr = match[3] || '';

        if (tagName === 'button') {
            if (closing) buttonDepth = Math.max(0, buttonDepth - 1);
            else if (!attrStr.trim().endsWith('/')) buttonDepth++;
        }
        if (!closing) handleAttrs(tagName, attrStr);
    }
}

// ####################################################
// Build output
// ####################################################

seedCuratedKeys();
getI18nJsFiles().forEach(scanJs);
getI18nPages().forEach(scanHtml);

const output = {};
for (const [ns, set] of Object.entries(buckets)) {
    const sorted = [...set].sort((a, b) => a.localeCompare(b));
    output[ns] = {};
    for (const key of sorted) output[ns][key] = key;
}

fs.mkdirSync(path.dirname(OUT_FILE), { recursive: true });
fs.writeFileSync(OUT_FILE, JSON.stringify(output, null, 4) + '\n', 'utf8');

const localeFiles = fs.readdirSync(LANG_DIR).filter((file) => file.endsWith('.json') && file !== 'en.json');
for (const file of localeFiles) {
    const filePath = path.join(LANG_DIR, file);
    const existing = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    const synced = {};
    for (const [namespace, englishEntries] of Object.entries(output)) {
        synced[namespace] = {};
        const existingEntries = existing[namespace] || {};
        for (const key of Object.keys(englishEntries)) {
            synced[namespace][key] = Object.hasOwn(existingEntries, key) ? existingEntries[key] : key;
        }
    }
    fs.writeFileSync(filePath, JSON.stringify(synced, null, 4) + '\n', 'utf8');
}

const counts = Object.entries(buckets)
    .map(([ns, set]) => `${ns}: ${set.size}`)
    .join(', ');
console.log(`Wrote ${OUT_FILE}`);
console.log(`Strings -> ${counts}`);
console.log(`Synchronized ${localeFiles.length} locale files`);
