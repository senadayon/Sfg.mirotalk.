'use strict';

const pathParts = window.location.pathname.split('/');
const roomPath = pathParts[pathParts.length - 1];
let roomId = roomPath;
try {
    roomId = decodeURIComponent(roomPath); // /join/abc%25 -> abc%
} catch {} // malformed percent-encoding: keep the raw value
const statusEl = document.getElementById('waitingStatus');
const loginLink = document.getElementById('loginLink');
const waitingRoomNameEl = document.getElementById('waitingRoomName');
const waitingRoomNameText = document.getElementById('waitingRoomNameText');
const waitingElapsedText = document.getElementById('waitingElapsedText');
const pollInterval = 5000;

// Store the room in the session for auto-join from the landing page after successful login
window.sessionStorage.roomID = roomId;

let intervalId = null;
let roomActive = false;
const waitStartTime = Date.now();
let elapsedTimerId = null;

if (roomId && roomId !== 'join') {
    waitingRoomNameText.textContent = roomId;
    waitingRoomNameEl.style.display = '';
}

function updateElapsedTime() {
    const seconds = Math.floor((Date.now() - waitStartTime) / 1000);
    if (seconds < 60) {
        waitingElapsedText.textContent = getWaitingRoomBrand('waitingRoomElapsedJust', 'Just started waiting');
    } else {
        const minutes = Math.floor(seconds / 60);
        const template = getWaitingRoomBrand('waitingRoomElapsedMinutes', 'Waiting for {minutes}');
        waitingElapsedText.textContent = template.replace('{minutes}', formatMinutes(minutes));
    }
}

// Unit in the UI language (e.g. "3 minuten" for nl). Stays English when Google Translate is
// allowed, since Google then translates the page from English.
function formatMinutes(minutes) {
    const i18n = window.i18n;
    const nativeLang = i18n && (i18n.googleAllowed === false || i18n.isNative?.()) ? i18n.getLang?.() : null;
    const lang = nativeLang || 'en';
    try {
        return new Intl.NumberFormat(lang, { style: 'unit', unit: 'minute', unitDisplay: 'long' }).format(minutes);
    } catch (e) {
        return minutes + (minutes === 1 ? ' minute' : ' minutes');
    }
}

// Show the configured text right away instead of the static HTML fallback until the first tick.
function onBrandReady(callback) {
    if (window.brandReady) return callback();
    document.addEventListener('brand:ready', () => callback(), { once: true });
}

onBrandReady(updateElapsedTime);
elapsedTimerId = setInterval(updateElapsedTime, 10000);

// Translate a UI string via the native i18n layer when active (falls back to English).
function translateWaitingText(text) {
    try {
        return window.i18n && typeof window.i18n.t === 'function' ? window.i18n.t(text, 'labels') : text;
    } catch (e) {
        return text;
    }
}

// Keeps the English source so i18n.js can re-translate the attribute on a live language switch.
function setTranslatedAttribute(element, attribute, source, namespace) {
    element[`__i18nAttr_${attribute}`] = source;
    let value = source;
    try {
        value = (window.i18n && typeof window.i18n.t === 'function' && window.i18n.t(source, namespace)) || source;
    } catch (e) {}
    element.setAttribute(attribute, value);
}

// Brand text (overridden by Brand.js if configured)
function getWaitingRoomBrand(key, fallback) {
    try {
        const value = (typeof brand !== 'undefined' && brand?.site?.[key]) || fallback;
        return translateWaitingText(value);
    } catch (e) {
        return translateWaitingText(fallback);
    }
}

// Set login link with room param so host returns to the room after login
if (roomId && roomId !== 'join') {
    loginLink.href = '/login?room=' + encodeURIComponent(roomId);
}

function flashCheckingState() {
    statusEl.textContent = getWaitingRoomBrand('waitingRoomStatus', 'Checking room status...');
    statusEl.classList.remove('ready');
    statusEl.classList.add('checking');
    setTimeout(() => statusEl.classList.remove('checking'), 600);
}

function checkRoom() {
    flashCheckingState();

    if (!roomId || roomId === 'join') return;

    axios
        .post('/isRoomActive', { roomId: roomId })
        .then(function (response) {
            if (response.data && response.data.message === true) {
                roomActive = true;
                if (waitingAudio) {
                    waitingAudio.pause();
                    waitingAudio = null;
                }
                statusEl.textContent = getWaitingRoomBrand('waitingRoomReady', 'Room is ready! Joining...');
                statusEl.classList.add('ready');
                setTimeout(function () {
                    window.location.href = '/join/' + encodeURIComponent(roomId);
                }, 800);
            } else {
                statusEl.textContent = getWaitingRoomBrand(
                    'waitingRoomWaiting',
                    'Waiting for host to start the meeting...'
                );
                scheduleCheck();
            }
        })
        .catch(function () {
            statusEl.textContent = getWaitingRoomBrand(
                'waitingRoomWaiting',
                'Waiting for host to start the meeting...'
            );
            scheduleCheck();
        });
}

function scheduleCheck() {
    if (document.hidden) {
        document.addEventListener('visibilitychange', function onVisible() {
            if (!document.hidden) {
                document.removeEventListener('visibilitychange', onVisible);
                checkRoom();
            }
        });
    } else {
        setTimeout(checkRoom, pollInterval);
    }
}

// Start polling after native translations are ready so status text is localized on first paint.
Promise.resolve(window.i18n && window.i18n.ready).then(checkRoom);

// Waiting room audio player
const audioPlayerEl = document.getElementById('waitingAudioPlayer');
const audioBtn = document.getElementById('waitingAudioBtn');
const audioIcon = document.getElementById('waitingAudioIcon');
const audioMuteBtn = document.getElementById('waitingAudioMute');
const audioMuteIcon = document.getElementById('waitingAudioMuteIcon');
const audioProgress = document.getElementById('waitingAudioProgress');

let waitingAudio = null;
let audioPlaying = false;

function initAudioPlayer() {
    const songUrl = getWaitingRoomBrand('waitingRoomSongUrl', '');
    if (!songUrl) return;

    audioPlayerEl.style.display = '';

    waitingAudio = new Audio(songUrl);
    waitingAudio.loop = true;
    waitingAudio.volume = 0.5;

    waitingAudio.addEventListener('timeupdate', function () {
        if (waitingAudio && waitingAudio.duration) {
            const pct = (waitingAudio.currentTime / waitingAudio.duration) * 100;
            audioProgress.style.width = pct + '%';
        }
    });

    audioBtn.onclick = function () {
        if (audioPlaying) {
            waitingAudio.pause();
            audioIcon.className = 'fa-solid fa-play';
            setTranslatedAttribute(audioBtn, 'title', 'Play music', 'buttons');
        } else {
            waitingAudio.play().catch(function () {});
            audioIcon.className = 'fa-solid fa-pause';
            setTranslatedAttribute(audioBtn, 'title', 'Pause music', 'buttons');
        }
        audioPlaying = !audioPlaying;
    };

    audioMuteBtn.onclick = function () {
        waitingAudio.muted = !waitingAudio.muted;
        audioMuteIcon.className = waitingAudio.muted ? 'fa-solid fa-volume-xmark' : 'fa-solid fa-volume-high';
        setTranslatedAttribute(audioMuteBtn, 'title', waitingAudio.muted ? 'Unmute' : 'Mute', 'buttons');
    };
}

// Initialize audio player after brand is loaded
setTimeout(initAudioPlayer, 1000);
